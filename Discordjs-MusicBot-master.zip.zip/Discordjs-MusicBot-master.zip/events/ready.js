module.exports = (client) => {
    console.log('Im alive as' + client.user.tag)
}
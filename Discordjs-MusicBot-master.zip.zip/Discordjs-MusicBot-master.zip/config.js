const config = {
    token: 'ODA5Mzc1MDA1NDAxOTM5OTY4.YCULNg.zZWG6RlhG3gq8T2-ZSZtDgZSOPE',
    prefix: '+'
}

module.exports = config;